package javamail;

public class JavaMail {

    public static void main(String[] args) {
        LogIn log = new LogIn();
        log.setVisible(true);

    }

}
